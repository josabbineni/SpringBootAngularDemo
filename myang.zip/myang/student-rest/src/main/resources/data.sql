
select * from student;